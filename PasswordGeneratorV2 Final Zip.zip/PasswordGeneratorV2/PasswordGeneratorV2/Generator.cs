﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PasswordGeneratorV2
{
	class Generator
	{
		public bool uppers;
		public bool lowers;
		public bool numbers;
		public bool symbols;

		public List<int> sizes;
		int min_size;
		int max_size;

		Random rand = new Random();
		StringBuilder builder;

		public Generator()
		{
			min_size = 4;
			max_size = 30;

			sizes = new List<int>();
			SetSizes(min_size, max_size);
		}

		private void SetSizes(int min, int max)
		{
			for (int i = 0; i < max - min + 1; i++)
			{
				sizes.Add(min + i);
			}
		}

		public string RequirementError()
		{
			return "Invalid requirements.";
		}

		//Constructs the string and returns it
		public string MakePassword(int size)
		{
			builder = new StringBuilder();

			for (int i = 0; i < size; i++)
			{
				int temp = rand.Next(1, 5);

				switch (temp)
				{
					case 1: //Upper
						{
							if (uppers)
								builder.Append(GetChar());
							else
								i--;

							break;
						}
					case 2: //Lower
						{
							if (lowers)
								builder.Append(Char.ToLower(GetChar()));
							else
								i--;

							break;
						}
					case 3: //Number
						{
							if (numbers)
								builder.Append(GetInt());
							else
								i--;

							break;
						}
					case 4: //Symbol
						{
							if (symbols)
								builder.Append(GetSymbol());
							else
								i--;

							break;
						}
				}
			}

			return builder.ToString();
		}

		//Returns an integer value
		public int GetInt()
		{
			return rand.Next(0, 10);
		}

		//Returns a character value
		public char GetChar()
		{
			return Convert.ToChar(Convert.ToInt32(Math.Floor(26 * rand.NextDouble() + 65)));
		}

		//Returns a symbol
		public char GetSymbol()
		{
			string symbols = $"!@#$%^&*()-=_+?><,./\\";
			
			return symbols[rand.Next(0, symbols.Length)];
		}
	}
}

