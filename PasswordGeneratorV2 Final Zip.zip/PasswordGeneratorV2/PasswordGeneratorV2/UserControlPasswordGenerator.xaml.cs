﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace PasswordGeneratorV2
{
	/// <summary>
	/// Interaction logic for UserControlPasswordGenerator.xaml
	/// </summary>
	public partial class UserControlPasswordGenerator : UserControl
	{
		Generator gen;

		public UserControlPasswordGenerator()
		{
			InitializeComponent();

			gen = new Generator();

			cbxSize.ItemsSource = gen.sizes;
		}

		private void btnGenerate_Clicked(object sender, RoutedEventArgs e)
		{
			gen.uppers = (bool)chbUppers.IsChecked;
			gen.lowers = (bool)chbLowers.IsChecked;
			gen.numbers = (bool)chbNumbers.IsChecked;
			gen.symbols = (bool)chbSymbols.IsChecked;

			if (!gen.uppers && !gen.lowers && !gen.numbers && !gen.symbols)
			{
				tbkPassword.Text = gen.RequirementError();
			}
			else
			{
				tbkPassword.Text = gen.MakePassword(Convert.ToInt32(cbxSize.Text));
			}
		}

		private void btnCopy_Click(object sender, RoutedEventArgs e)
		{
			Clipboard.SetText(tbkPassword.Text);
		}
	}
}
