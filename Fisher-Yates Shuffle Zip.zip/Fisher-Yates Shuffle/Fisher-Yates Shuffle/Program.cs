﻿using System;
using static System.Console;
using System.Collections.Generic;

namespace Fisher_Yates_Shuffle
{
	class Program
	{
		static void Main(string[] args)
		{
			Shuffler shuffler = new Shuffler();
			ReadKey();
		}
	}
}
