﻿using System;

namespace DataStructures
{
	class Program
	{
		static void Main(string[] args)
		{
			Dishwasher washer = new Dishwasher();
			Console.WriteLine("");
			Roster roster = new Roster();
			Console.ReadKey();
		}
	}
}
