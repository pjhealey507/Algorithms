﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataStructures
{
	class Employee
	{
		public string name;
		public int ID;

		public Employee(string n, int ID)
		{
			name = n;
			this.ID = ID;
		}
	}
}
